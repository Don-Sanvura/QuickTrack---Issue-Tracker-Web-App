import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Notification } from '@/types';
import { getNotifications, saveNotifications } from '@/lib/localStorage';
import { useAuth } from './AuthContext';
import { v4 as uuidv4 } from 'uuid';

interface NotificationContextType {
  notifications: Notification[];
  getUserNotifications: () => Notification[];
  addNotification: (userId: string, title: string, message: string) => void;
  markAsRead: (id: string) => void;
  markAllAsRead: () => void;
  deleteNotification: (id: string) => void;
  unreadCount: number;
}

const NotificationContext = createContext<NotificationContextType>({
  notifications: [],
  getUserNotifications: () => [],
  addNotification: () => {},
  markAsRead: () => {},
  markAllAsRead: () => {},
  deleteNotification: () => {},
  unreadCount: 0
});

export const useNotifications = () => useContext(NotificationContext);

interface NotificationProviderProps {
  children: ReactNode;
}

export const NotificationProvider = ({ children }: NotificationProviderProps) => {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const { currentUser } = useAuth();

  useEffect(() => {
    // Load notifications from localStorage on init
    setNotifications(getNotifications());
  }, []);

  // Update unread count when notifications or current user change
  useEffect(() => {
    if (currentUser) {
      const userNotifications = notifications.filter(n => n.userId === currentUser.id);
      const unread = userNotifications.filter(n => !n.isRead).length;
      setUnreadCount(unread);
    } else {
      setUnreadCount(0);
    }
  }, [notifications, currentUser]);

  const getUserNotifications = () => {
    if (!currentUser) return [];
    return notifications.filter(n => n.userId === currentUser.id);
  };

  const addNotification = (userId: string, title: string, message: string) => {
    const newNotification: Notification = {
      id: uuidv4(),
      userId,
      title,
      message,
      isRead: false,
      createdAt: new Date().toISOString()
    };
    
    const updatedNotifications = [...notifications, newNotification];
    setNotifications(updatedNotifications);
    saveNotifications(updatedNotifications);
  };

  const markAsRead = (id: string) => {
    const updatedNotifications = notifications.map(n => 
      n.id === id ? { ...n, isRead: true } : n
    );
    
    setNotifications(updatedNotifications);
    saveNotifications(updatedNotifications);
  };

  const markAllAsRead = () => {
    if (!currentUser) return;
    
    const updatedNotifications = notifications.map(n => 
      n.userId === currentUser.id ? { ...n, isRead: true } : n
    );
    
    setNotifications(updatedNotifications);
    saveNotifications(updatedNotifications);
  };

  const deleteNotification = (id: string) => {
    const updatedNotifications = notifications.filter(n => n.id !== id);
    setNotifications(updatedNotifications);
    saveNotifications(updatedNotifications);
  };

  return (
    <NotificationContext.Provider 
      value={{ 
        notifications, 
        getUserNotifications, 
        addNotification, 
        markAsRead, 
        markAllAsRead, 
        deleteNotification,
        unreadCount
      }}
    >
      {children}
    </NotificationContext.Provider>
  );
};