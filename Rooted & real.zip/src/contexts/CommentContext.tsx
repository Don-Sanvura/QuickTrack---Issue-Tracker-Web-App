import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Comment } from '@/types';
import { getComments, saveComments } from '@/lib/localStorage';
import { useAuth } from './AuthContext';
import { v4 as uuidv4 } from 'uuid';

interface CommentContextType {
  comments: Comment[];
  getTaskComments: (taskId: string) => Comment[];
  addComment: (taskId: string, content: string) => void;
  deleteComment: (id: string) => void;
}

const CommentContext = createContext<CommentContextType>({
  comments: [],
  getTaskComments: () => [],
  addComment: () => {},
  deleteComment: () => {}
});

export const useComments = () => useContext(CommentContext);

interface CommentProviderProps {
  children: ReactNode;
}

export const CommentProvider = ({ children }: CommentProviderProps) => {
  const [comments, setComments] = useState<Comment[]>([]);
  const { currentUser } = useAuth();

  useEffect(() => {
    // Load comments from localStorage on init
    setComments(getComments());
  }, []);

  const getTaskComments = (taskId: string) => {
    return comments.filter(comment => comment.taskId === taskId);
  };

  const addComment = (taskId: string, content: string) => {
    if (!currentUser) return;
    
    const newComment: Comment = {
      id: uuidv4(),
      taskId,
      userId: currentUser.id,
      content,
      createdAt: new Date().toISOString()
    };
    
    const updatedComments = [...comments, newComment];
    setComments(updatedComments);
    saveComments(updatedComments);
  };

  const deleteComment = (id: string) => {
    const updatedComments = comments.filter(comment => comment.id !== id);
    setComments(updatedComments);
    saveComments(updatedComments);
  };

  return (
    <CommentContext.Provider 
      value={{ comments, getTaskComments, addComment, deleteComment }}
    >
      {children}
    </CommentContext.Provider>
  );
};