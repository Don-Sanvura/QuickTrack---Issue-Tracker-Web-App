import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Project } from '@/types';
import { getProjects, saveProjects } from '@/lib/localStorage';
import { useAuth } from './AuthContext';
import { v4 as uuidv4 } from 'uuid';

interface ProjectContextType {
  projects: Project[];
  getProject: (id: string) => Project | undefined;
  createProject: (name: string, description: string) => void;
  updateProject: (id: string, name: string, description: string) => void;
  deleteProject: (id: string) => void;
}

const ProjectContext = createContext<ProjectContextType>({
  projects: [],
  getProject: () => undefined,
  createProject: () => {},
  updateProject: () => {},
  deleteProject: () => {}
});

export const useProjects = () => useContext(ProjectContext);

interface ProjectProviderProps {
  children: ReactNode;
}

export const ProjectProvider = ({ children }: ProjectProviderProps) => {
  const [projects, setProjects] = useState<Project[]>([]);
  const { currentUser } = useAuth();

  useEffect(() => {
    // Load projects from localStorage on init
    setProjects(getProjects());
  }, []);

  const getProject = (id: string) => {
    return projects.find(project => project.id === id);
  };

  const createProject = (name: string, description: string) => {
    if (!currentUser) return;
    
    const newProject: Project = {
      id: uuidv4(),
      name,
      description,
      createdBy: currentUser.id,
      createdAt: new Date().toISOString()
    };
    
    const updatedProjects = [...projects, newProject];
    setProjects(updatedProjects);
    saveProjects(updatedProjects);
  };

  const updateProject = (id: string, name: string, description: string) => {
    const updatedProjects = projects.map(project => 
      project.id === id ? { ...project, name, description } : project
    );
    
    setProjects(updatedProjects);
    saveProjects(updatedProjects);
  };

  const deleteProject = (id: string) => {
    const updatedProjects = projects.filter(project => project.id !== id);
    setProjects(updatedProjects);
    saveProjects(updatedProjects);
  };

  return (
    <ProjectContext.Provider 
      value={{ projects, getProject, createProject, updateProject, deleteProject }}
    >
      {children}
    </ProjectContext.Provider>
  );
};