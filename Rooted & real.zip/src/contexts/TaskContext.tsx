import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Task, TaskStatus, TaskPriority } from '@/types';
import { getTasks, saveTasks } from '@/lib/localStorage';
import { useAuth } from './AuthContext';
import { v4 as uuidv4 } from 'uuid';

interface TaskContextType {
  tasks: Task[];
  getTask: (id: string) => Task | undefined;
  getProjectTasks: (projectId: string) => Task[];
  createTask: (data: Omit<Task, 'id' | 'createdBy' | 'createdAt' | 'updatedAt'>) => void;
  updateTask: (id: string, data: Partial<Omit<Task, 'id' | 'createdBy' | 'createdAt'>>) => void;
  updateTaskStatus: (id: string, status: TaskStatus) => void;
  deleteTask: (id: string) => void;
  getTaskStats: () => {
    total: number;
    byStatus: Record<TaskStatus, number>;
    byPriority: Record<TaskPriority, number>;
  };
}

const TaskContext = createContext<TaskContextType>({
  tasks: [],
  getTask: () => undefined,
  getProjectTasks: () => [],
  createTask: () => {},
  updateTask: () => {},
  updateTaskStatus: () => {},
  deleteTask: () => {},
  getTaskStats: () => ({ total: 0, byStatus: {} as Record<TaskStatus, number>, byPriority: {} as Record<TaskPriority, number> })
});

export const useTasks = () => useContext(TaskContext);

interface TaskProviderProps {
  children: ReactNode;
}

export const TaskProvider = ({ children }: TaskProviderProps) => {
  const [tasks, setTasks] = useState<Task[]>([]);
  const { currentUser } = useAuth();

  useEffect(() => {
    // Load tasks from localStorage on init
    setTasks(getTasks());
  }, []);

  const getTask = (id: string) => {
    return tasks.find(task => task.id === id);
  };

  const getProjectTasks = (projectId: string) => {
    return tasks.filter(task => task.projectId === projectId);
  };

  const createTask = (data: Omit<Task, 'id' | 'createdBy' | 'createdAt' | 'updatedAt'>) => {
    if (!currentUser) return;
    
    const now = new Date().toISOString();
    
    const newTask: Task = {
      id: uuidv4(),
      createdBy: currentUser.id,
      createdAt: now,
      updatedAt: now,
      ...data
    };
    
    const updatedTasks = [...tasks, newTask];
    setTasks(updatedTasks);
    saveTasks(updatedTasks);
  };

  const updateTask = (id: string, data: Partial<Omit<Task, 'id' | 'createdBy' | 'createdAt'>>) => {
    const updatedTasks = tasks.map(task => {
      if (task.id === id) {
        return { 
          ...task, 
          ...data, 
          updatedAt: new Date().toISOString() 
        };
      }
      return task;
    });
    
    setTasks(updatedTasks);
    saveTasks(updatedTasks);
  };

  const updateTaskStatus = (id: string, status: TaskStatus) => {
    updateTask(id, { status });
  };

  const deleteTask = (id: string) => {
    const updatedTasks = tasks.filter(task => task.id !== id);
    setTasks(updatedTasks);
    saveTasks(updatedTasks);
  };

  const getTaskStats = () => {
    const stats = {
      total: tasks.length,
      byStatus: {
        [TaskStatus.TODO]: 0,
        [TaskStatus.IN_PROGRESS]: 0,
        [TaskStatus.REVIEW]: 0,
        [TaskStatus.DONE]: 0
      },
      byPriority: {
        [TaskPriority.LOW]: 0,
        [TaskPriority.MEDIUM]: 0,
        [TaskPriority.HIGH]: 0,
        [TaskPriority.CRITICAL]: 0
      }
    };

    tasks.forEach(task => {
      stats.byStatus[task.status]++;
      stats.byPriority[task.priority]++;
    });

    return stats;
  };

  return (
    <TaskContext.Provider 
      value={{ 
        tasks, 
        getTask, 
        getProjectTasks, 
        createTask, 
        updateTask, 
        updateTaskStatus, 
        deleteTask,
        getTaskStats 
      }}
    >
      {children}
    </TaskContext.Provider>
  );
};