import { User, Project, Task, Comment, Notification, UserRole, TaskStatus, TaskPriority } from "@/types";

// LocalStorage keys
const USERS_KEY = 'quicktrack-users';
const CURRENT_USER_KEY = 'quicktrack-current-user';
const PROJECTS_KEY = 'quicktrack-projects';
const TASKS_KEY = 'quicktrack-tasks';
const COMMENTS_KEY = 'quicktrack-comments';
const NOTIFICATIONS_KEY = 'quicktrack-notifications';

// User methods
export const getUsers = (): User[] => {
  const users = localStorage.getItem(USERS_KEY);
  return users ? JSON.parse(users) : [];
};

export const saveUsers = (users: User[]) => {
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
};

export const getCurrentUser = (): User | null => {
  const user = localStorage.getItem(CURRENT_USER_KEY);
  return user ? JSON.parse(user) : null;
};

export const saveCurrentUser = (user: User | null) => {
  if (user) {
    localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(user));
  } else {
    localStorage.removeItem(CURRENT_USER_KEY);
  }
};

// Project methods
export const getProjects = (): Project[] => {
  const projects = localStorage.getItem(PROJECTS_KEY);
  return projects ? JSON.parse(projects) : [];
};

export const saveProjects = (projects: Project[]) => {
  localStorage.setItem(PROJECTS_KEY, JSON.stringify(projects));
};

// Task methods
export const getTasks = (): Task[] => {
  const tasks = localStorage.getItem(TASKS_KEY);
  return tasks ? JSON.parse(tasks) : [];
};

export const saveTasks = (tasks: Task[]) => {
  localStorage.setItem(TASKS_KEY, JSON.stringify(tasks));
};

// Comment methods
export const getComments = (): Comment[] => {
  const comments = localStorage.getItem(COMMENTS_KEY);
  return comments ? JSON.parse(comments) : [];
};

export const saveComments = (comments: Comment[]) => {
  localStorage.setItem(COMMENTS_KEY, JSON.stringify(comments));
};

// Notification methods
export const getNotifications = (): Notification[] => {
  const notifications = localStorage.getItem(NOTIFICATIONS_KEY);
  return notifications ? JSON.parse(notifications) : [];
};

export const saveNotifications = (notifications: Notification[]) => {
  localStorage.setItem(NOTIFICATIONS_KEY, JSON.stringify(notifications));
};

// Init demo data if not exists
export const initDemoData = () => {
  if (getUsers().length === 0) {
    // Create demo users
    const adminUser: User = {
      id: "1",
      name: "Admin User",
      email: "admin@quicktrack.com",
      password: "admin123", // In a real app, this would be hashed
      role: "admin" as UserRole,
      createdAt: new Date().toISOString()
    };

    const memberUser: User = {
      id: "2",
      name: "Member User",
      email: "member@quicktrack.com",
      password: "member123", // In a real app, this would be hashed
      role: "member" as UserRole,
      createdAt: new Date().toISOString()
    };

    saveUsers([adminUser, memberUser]);

    // Create a demo project
    const demoProject: Project = {
      id: "1",
      name: "Website Redesign",
      description: "Redesign the company website with modern UI/UX",
      createdBy: "1",
      createdAt: new Date().toISOString()
    };

    saveProjects([demoProject]);

    // Create demo tasks
    const demoTasks: Task[] = [
      {
        id: "1",
        projectId: "1",
        title: "Design homepage mockup",
        description: "Create a mockup design for the homepage using Figma",
        status: "todo" as TaskStatus,
        priority: "high" as TaskPriority,
        assignedTo: "2",
        createdBy: "1",
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString() // 7 days from now
      },
      {
        id: "2",
        projectId: "1",
        title: "Implement navigation component",
        description: "Create responsive navigation bar with mobile menu",
        status: "in-progress" as TaskStatus,
        priority: "medium" as TaskPriority,
        assignedTo: "2",
        createdBy: "1",
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        dueDate: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toISOString() // 5 days from now
      },
      {
        id: "3",
        projectId: "1",
        title: "Set up analytics",
        description: "Integrate Google Analytics and set up conversion tracking",
        status: "done" as TaskStatus,
        priority: "low" as TaskPriority,
        assignedTo: "1",
        createdBy: "1",
        createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(), // 3 days ago
        updatedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(), // 1 day ago
      }
    ];

    saveTasks(demoTasks);

    // Create demo comments
    const demoComments: Comment[] = [
      {
        id: "1",
        taskId: "1",
        userId: "1",
        content: "Let's make sure we follow the brand guidelines for colors and typography.",
        createdAt: new Date().toISOString()
      },
      {
        id: "2",
        taskId: "1",
        userId: "2",
        content: "I'll prepare the first draft by tomorrow.",
        createdAt: new Date().toISOString()
      }
    ];

    saveComments(demoComments);

    // Create demo notifications
    const demoNotifications: Notification[] = [
      {
        id: "1",
        userId: "2",
        title: "New task assigned",
        message: "You have been assigned to 'Design homepage mockup'",
        isRead: false,
        createdAt: new Date().toISOString()
      }
    ];

    saveNotifications(demoNotifications);
  }
};