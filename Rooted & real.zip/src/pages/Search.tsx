import { useEffect, useState } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import AppLayout from '@/components/layout/AppLayout';
import { useTasks } from '@/contexts/TaskContext';
import { useProjects } from '@/contexts/ProjectContext';
import { Task } from '@/types';
import TaskCard from '@/components/tasks/TaskCard';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search as SearchIcon, Filter, X } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { TaskStatus, TaskPriority } from '@/types';

const Search = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const { tasks, updateTaskStatus, deleteTask } = useTasks();
  const { projects } = useProjects();
  const navigate = useNavigate();
  
  const initialQuery = searchParams.get('q') || '';
  const [query, setQuery] = useState(initialQuery);
  const [results, setResults] = useState<Task[]>([]);
  
  // Filter states
  const [statusFilter, setStatusFilter] = useState<TaskStatus[]>([]);
  const [priorityFilter, setPriorityFilter] = useState<TaskPriority[]>([]);
  const [projectFilter, setProjectFilter] = useState<string[]>([]);
  
  useEffect(() => {
    // Update search bar when URL changes
    setQuery(searchParams.get('q') || '');
  }, [searchParams]);
  
  useEffect(() => {
    // Perform search when query or filters change
    if (query.trim() === '') {
      setResults([]);
      return;
    }
    
    // Filter tasks by query and filters
    const filtered = tasks.filter(task => {
      // Match query
      const matchesQuery = 
        task.title.toLowerCase().includes(query.toLowerCase()) ||
        task.description.toLowerCase().includes(query.toLowerCase());
      
      // Match status filter
      const matchesStatus = statusFilter.length === 0 || statusFilter.includes(task.status as TaskStatus);
      
      // Match priority filter
      const matchesPriority = priorityFilter.length === 0 || priorityFilter.includes(task.priority as TaskPriority);
      
      // Match project filter
      const matchesProject = projectFilter.length === 0 || projectFilter.includes(task.projectId);
      
      return matchesQuery && matchesStatus && matchesPriority && matchesProject;
    });
    
    setResults(filtered);
  }, [query, tasks, statusFilter, priorityFilter, projectFilter]);
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      searchParams.set('q', query);
      setSearchParams(searchParams);
    }
  };
  
  const handleTaskView = (projectId: string, taskId: string) => {
    navigate(`/projects/${projectId}?task=${taskId}`);
  };
  
  const handleClearFilters = () => {
    setStatusFilter([]);
    setPriorityFilter([]);
    setProjectFilter([]);
  };
  
  const toggleStatusFilter = (status: TaskStatus) => {
    setStatusFilter(prev => 
      prev.includes(status) 
        ? prev.filter(s => s !== status) 
        : [...prev, status]
    );
  };
  
  const togglePriorityFilter = (priority: TaskPriority) => {
    setPriorityFilter(prev => 
      prev.includes(priority) 
        ? prev.filter(p => p !== priority) 
        : [...prev, priority]
    );
  };
  
  const toggleProjectFilter = (projectId: string) => {
    setProjectFilter(prev => 
      prev.includes(projectId) 
        ? prev.filter(p => p !== projectId) 
        : [...prev, projectId]
    );
  };
  
  // Status options
  const statusOptions = [
    { value: TaskStatus.TODO, label: 'To Do' },
    { value: TaskStatus.IN_PROGRESS, label: 'In Progress' },
    { value: TaskStatus.REVIEW, label: 'Review' },
    { value: TaskStatus.DONE, label: 'Done' },
  ];
  
  // Priority options
  const priorityOptions = [
    { value: TaskPriority.LOW, label: 'Low' },
    { value: TaskPriority.MEDIUM, label: 'Medium' },
    { value: TaskPriority.HIGH, label: 'High' },
    { value: TaskPriority.CRITICAL, label: 'Critical' },
  ];
  
  const hasActiveFilters = statusFilter.length > 0 || priorityFilter.length > 0 || projectFilter.length > 0;

  return (
    <AppLayout>
      <div className="mb-6">
        <h1 className="text-3xl font-bold mb-2">Search Results</h1>
        <p className="text-muted-foreground">
          {results.length} {results.length === 1 ? 'result' : 'results'} found for "{query}"
        </p>
      </div>
      
      <form onSubmit={handleSubmit} className="flex gap-2 mb-6">
        <div className="relative flex-1">
          <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search tasks..."
            className="pl-10"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>
        
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" className="gap-2">
              <Filter className="h-4 w-4" />
              <span>Filter</span>
              {hasActiveFilters && (
                <span className="flex h-2 w-2 rounded-full bg-primary"></span>
              )}
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            <DropdownMenuLabel>Filter Tasks</DropdownMenuLabel>
            <DropdownMenuSeparator />
            
            <DropdownMenuLabel className="text-xs">Status</DropdownMenuLabel>
            {statusOptions.map(option => (
              <DropdownMenuCheckboxItem
                key={option.value}
                checked={statusFilter.includes(option.value)}
                onCheckedChange={() => toggleStatusFilter(option.value)}
              >
                {option.label}
              </DropdownMenuCheckboxItem>
            ))}
            
            <DropdownMenuSeparator />
            <DropdownMenuLabel className="text-xs">Priority</DropdownMenuLabel>
            {priorityOptions.map(option => (
              <DropdownMenuCheckboxItem
                key={option.value}
                checked={priorityFilter.includes(option.value)}
                onCheckedChange={() => togglePriorityFilter(option.value)}
              >
                {option.label}
              </DropdownMenuCheckboxItem>
            ))}
            
            <DropdownMenuSeparator />
            <DropdownMenuLabel className="text-xs">Project</DropdownMenuLabel>
            {projects.map(project => (
              <DropdownMenuCheckboxItem
                key={project.id}
                checked={projectFilter.includes(project.id)}
                onCheckedChange={() => toggleProjectFilter(project.id)}
              >
                {project.name}
              </DropdownMenuCheckboxItem>
            ))}
            
            {hasActiveFilters && (
              <>
                <DropdownMenuSeparator />
                <Button 
                  variant="ghost" 
                  className="w-full justify-start text-sm h-auto py-1.5 px-2" 
                  onClick={handleClearFilters}
                >
                  <X className="h-4 w-4 mr-2" />
                  Clear filters
                </Button>
              </>
            )}
          </DropdownMenuContent>
        </DropdownMenu>
        
        <Button type="submit">Search</Button>
      </form>
      
      {query && results.length === 0 ? (
        <div className="text-center py-12 bg-secondary/30 rounded-lg">
          <h3 className="text-lg font-medium mb-2">No results found</h3>
          <p className="text-muted-foreground">
            Try adjusting your search query or filters
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {results.map(task => (
            <TaskCard 
              key={task.id} 
              task={task}
              onView={() => handleTaskView(task.projectId, task.id)}
              onEdit={() => handleTaskView(task.projectId, task.id)}
              onDelete={() => deleteTask(task.id)}
              onStatusChange={(status) => updateTaskStatus(task.id, status)}
            />
          ))}
        </div>
      )}
    </AppLayout>
  );
};

export default Search;