import AppLayout from '@/components/layout/AppLayout';
import TasksChart from '@/components/analytics/TasksChart';
import PriorityDistribution from '@/components/analytics/PriorityDistribution';
import { useTasks } from '@/contexts/TaskContext';
import { TaskStatus } from '@/types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { subDays } from 'date-fns';

const Analytics = () => {
  const { tasks } = useTasks();
  
  // Calculate task completion rate
  const last30Days = subDays(new Date(), 30).getTime();
  const tasksInLast30Days = tasks.filter(task => new Date(task.createdAt).getTime() >= last30Days);
  const completedTasks = tasksInLast30Days.filter(task => task.status === TaskStatus.DONE);
  const completionRate = tasksInLast30Days.length > 0
    ? Math.round((completedTasks.length / tasksInLast30Days.length) * 100)
    : 0;
  
  // Calculate avg time to completion (in days)
  let avgCompletionTime = 0;
  if (completedTasks.length > 0) {
    const totalDays = completedTasks.reduce((total, task) => {
      const createdAt = new Date(task.createdAt).getTime();
      const updatedAt = new Date(task.updatedAt).getTime();
      const days = (updatedAt - createdAt) / (1000 * 60 * 60 * 24);
      return total + days;
    }, 0);
    avgCompletionTime = Math.round((totalDays / completedTasks.length) * 10) / 10; // Round to 1 decimal place
  }
  
  // Generate stats cards data
  const statsCards = [
    {
      title: 'Task Completion Rate',
      value: `${completionRate}%`,
      description: 'Last 30 days',
      trend: completionRate >= 70 ? 'positive' : completionRate >= 40 ? 'neutral' : 'negative',
    },
    {
      title: 'Avg. Completion Time',
      value: avgCompletionTime > 0 ? `${avgCompletionTime} days` : 'N/A',
      description: 'From creation to done',
      trend: avgCompletionTime <= 3 ? 'positive' : avgCompletionTime <= 7 ? 'neutral' : 'negative',
    },
    {
      title: 'Active Tasks',
      value: tasks.filter(task => task.status !== TaskStatus.DONE).length.toString(),
      description: 'Not completed',
      trend: 'neutral',
    },
    {
      title: 'Critical Issues',
      value: tasks.filter(task => task.priority === 'critical').length.toString(),
      description: 'High priority items',
      trend: 'neutral',
    }
  ];
  
  return (
    <AppLayout>
      <div className="mb-6">
        <h1 className="text-3xl font-bold mb-2">Analytics</h1>
        <p className="text-muted-foreground">
          Analyze your team's performance and task trends
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
        {statsCards.map((stat, index) => (
          <Card key={index}>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                {stat.title}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stat.value}</div>
              <p className="text-xs text-muted-foreground mt-1">
                {stat.description}
              </p>
            </CardContent>
          </Card>
        ))}
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <TasksChart />
        <PriorityDistribution />
      </div>
    </AppLayout>
  );
};

export default Analytics;