import { useState, useEffect } from 'react';
import { useParams, useNavigate, useSearchParams } from 'react-router-dom';
import AppLayout from '@/components/layout/AppLayout';
import { useProjects } from '@/contexts/ProjectContext';
import { useTasks } from '@/contexts/TaskContext';
import { TaskStatus } from '@/types';
import TaskCard from '@/components/tasks/TaskCard';
import TaskForm from '@/components/tasks/TaskForm';
import TaskDetail from '@/components/tasks/TaskDetail';
import { Button } from '@/components/ui/button';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Plus, Filter, Search, ArrowLeft } from 'lucide-react';

const ProjectDetail = () => {
  const { projectId } = useParams<{ projectId: string }>();
  const [searchParams, setSearchParams] = useSearchParams();
  const { projects, getProject } = useProjects();
  const { tasks, getProjectTasks, updateTaskStatus, deleteTask } = useTasks();
  const navigate = useNavigate();
  
  const [isAddTaskDialogOpen, setIsAddTaskDialogOpen] = useState(false);
  const [editingTaskId, setEditingTaskId] = useState<string | null>(null);
  const [viewingTaskId, setViewingTaskId] = useState<string | null>(searchParams.get('task'));
  const [taskToDelete, setTaskToDelete] = useState<string | null>(null);
  const [statusFilter, setStatusFilter] = useState<TaskStatus | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const project = projectId ? getProject(projectId) : null;
  const projectTasks = projectId ? getProjectTasks(projectId) : [];
  
  // Filter tasks by status and search query
  const filteredTasks = projectTasks.filter(task => {
    const matchesStatus = statusFilter === 'all' || task.status === statusFilter;
    const matchesSearch = task.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          task.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesStatus && matchesSearch;
  });
  
  // Group tasks by status
  const tasksByStatus = {
    [TaskStatus.TODO]: filteredTasks.filter(task => task.status === TaskStatus.TODO),
    [TaskStatus.IN_PROGRESS]: filteredTasks.filter(task => task.status === TaskStatus.IN_PROGRESS),
    [TaskStatus.REVIEW]: filteredTasks.filter(task => task.status === TaskStatus.REVIEW),
    [TaskStatus.DONE]: filteredTasks.filter(task => task.status === TaskStatus.DONE),
  };
  
  useEffect(() => {
    // If project doesn't exist, navigate back to projects list
    if (projectId && projects.length > 0 && !project) {
      navigate('/projects');
    }
  }, [project, projectId, projects.length, navigate]);
  
  useEffect(() => {
    // Update viewingTaskId when searchParams change
    const taskParam = searchParams.get('task');
    if (taskParam) {
      setViewingTaskId(taskParam);
    }
  }, [searchParams]);

  const handleAddTaskSuccess = () => {
    setIsAddTaskDialogOpen(false);
  };
  
  const handleEditTaskSuccess = () => {
    setEditingTaskId(null);
  };
  
  const handleStatusChange = (taskId: string, newStatus: TaskStatus) => {
    updateTaskStatus(taskId, newStatus);
  };
  
  const handleDeleteConfirm = () => {
    if (taskToDelete) {
      deleteTask(taskToDelete);
      if (viewingTaskId === taskToDelete) {
        setViewingTaskId(null);
        searchParams.delete('task');
        setSearchParams(searchParams);
      }
      setTaskToDelete(null);
    }
  };
  
  const handleViewTask = (taskId: string) => {
    setViewingTaskId(taskId);
    searchParams.set('task', taskId);
    setSearchParams(searchParams);
  };
  
  const handleCloseTaskView = () => {
    setViewingTaskId(null);
    searchParams.delete('task');
    setSearchParams(searchParams);
  };
  
  const editingTask = editingTaskId ? tasks.find(t => t.id === editingTaskId) : null;
  const viewingTask = viewingTaskId ? tasks.find(t => t.id === viewingTaskId) : null;
  const taskToDeleteData = taskToDelete ? tasks.find(t => t.id === taskToDelete) : null;
  
  // Status tabs configuration
  const statusTabs = [
    { value: 'all', label: 'All' },
    { value: TaskStatus.TODO, label: 'To Do' },
    { value: TaskStatus.IN_PROGRESS, label: 'In Progress' },
    { value: TaskStatus.REVIEW, label: 'Review' },
    { value: TaskStatus.DONE, label: 'Done' },
  ];

  if (!project) {
    return null; // Will redirect due to useEffect
  }

  return (
    <AppLayout>
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => navigate('/projects')}
              className="-ml-2"
            >
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <h1 className="text-3xl font-bold">{project.name}</h1>
          </div>
          <p className="text-muted-foreground mt-1">
            {project.description || "No description provided"}
          </p>
        </div>
        <Button onClick={() => setIsAddTaskDialogOpen(true)}>
          <Plus className="h-4 w-4 mr-2" />
          New Task
        </Button>
      </div>

      {viewingTask ? (
        <div className="mb-6">
          <Button 
            variant="outline" 
            size="sm" 
            onClick={handleCloseTaskView}
            className="mb-4"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Project
          </Button>
          <TaskDetail 
            task={viewingTask}
            onEdit={() => setEditingTaskId(viewingTask.id)}
            onDelete={() => setTaskToDelete(viewingTask.id)}
            onStatusChange={(status) => handleStatusChange(viewingTask.id, status)}
          />
        </div>
      ) : (
        <>
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search tasks..."
                  className="pl-10"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </div>
            <Tabs 
              value={statusFilter} 
              onValueChange={(value) => setStatusFilter(value as TaskStatus | 'all')}
              className="w-full sm:w-auto"
            >
              <TabsList className="w-full">
                {statusTabs.map(tab => (
                  <TabsTrigger key={tab.value} value={tab.value} className="flex-1 sm:flex-none">
                    {tab.label}
                    {tab.value !== 'all' && (
                      <Badge className="ml-2 bg-primary/20 text-foreground">
                        {tasksByStatus[tab.value as TaskStatus].length}
                      </Badge>
                    )}
                  </TabsTrigger>
                ))}
              </TabsList>
            </Tabs>
          </div>
          
          {filteredTasks.length === 0 ? (
            <div className="text-center py-12 bg-secondary/30 rounded-lg">
              <h3 className="text-lg font-medium mb-2">No tasks found</h3>
              {statusFilter !== 'all' || searchQuery ? (
                <p className="text-muted-foreground mb-6">
                  Try adjusting your filters or search query
                </p>
              ) : (
                <p className="text-muted-foreground mb-6">
                  Create a new task to get started
                </p>
              )}
              <Button onClick={() => setIsAddTaskDialogOpen(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Create Task
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {statusFilter === 'all' ? (
                Object.entries(tasksByStatus).map(([status, tasks]) => (
                  tasks.length > 0 && (
                    <div key={status} className="space-y-4">
                      <div className="font-medium">{
                        status === TaskStatus.TODO ? 'To Do' :
                        status === TaskStatus.IN_PROGRESS ? 'In Progress' :
                        status === TaskStatus.REVIEW ? 'Review' : 'Done'
                      }</div>
                      {tasks.map((task) => (
                        <TaskCard
                          key={task.id}
                          task={task}
                          onView={() => handleViewTask(task.id)}
                          onEdit={() => setEditingTaskId(task.id)}
                          onDelete={() => setTaskToDelete(task.id)}
                          onStatusChange={(status) => handleStatusChange(task.id, status)}
                        />
                      ))}
                    </div>
                  )
                ))
              ) : (
                filteredTasks.map((task) => (
                  <TaskCard
                    key={task.id}
                    task={task}
                    onView={() => handleViewTask(task.id)}
                    onEdit={() => setEditingTaskId(task.id)}
                    onDelete={() => setTaskToDelete(task.id)}
                    onStatusChange={(status) => handleStatusChange(task.id, status)}
                  />
                ))
              )}
            </div>
          )}
        </>
      )}
      
      {/* Add Task Dialog */}
      <Dialog open={isAddTaskDialogOpen} onOpenChange={setIsAddTaskDialogOpen}>
        <DialogContent className="max-w-lg">
          {projectId && (
            <TaskForm 
              projectId={projectId}
              onSuccess={handleAddTaskSuccess} 
              onCancel={() => setIsAddTaskDialogOpen(false)} 
            />
          )}
        </DialogContent>
      </Dialog>
      
      {/* Edit Task Dialog */}
      <Dialog 
        open={!!editingTaskId} 
        onOpenChange={(open) => !open && setEditingTaskId(null)}
      >
        <DialogContent className="max-w-lg">
          {editingTask && projectId && (
            <TaskForm 
              projectId={projectId}
              taskId={editingTask.id}
              onSuccess={handleEditTaskSuccess} 
              onCancel={() => setEditingTaskId(null)} 
            />
          )}
        </DialogContent>
      </Dialog>
      
      {/* Delete Task Confirmation Dialog */}
      <Dialog 
        open={!!taskToDelete} 
        onOpenChange={(open) => !open && setTaskToDelete(null)}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Task</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete "{taskToDeleteData?.title}"? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2 sm:gap-0">
            <Button variant="outline" onClick={() => setTaskToDelete(null)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDeleteConfirm}>
              Delete Task
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AppLayout>
  );
};

export default ProjectDetail;