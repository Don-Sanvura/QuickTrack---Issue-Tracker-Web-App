import AppLayout from '@/components/layout/AppLayout';
import TasksOverview from '@/components/dashboard/TasksOverview';
import RecentTasks from '@/components/dashboard/RecentTasks';
import { useProjects } from '@/contexts/ProjectContext';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { FolderKanban, Plus } from 'lucide-react';

const Dashboard = () => {
  const { projects } = useProjects();
  
  return (
    <AppLayout>
      <div className="mb-6">
        <h1 className="text-3xl font-bold mb-2">Dashboard</h1>
        <p className="text-muted-foreground">
          Welcome back to QuickTrack. Here's an overview of your tasks and projects.
        </p>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <TasksOverview />
          <RecentTasks />
        </div>
        
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-xl">Projects</CardTitle>
            </CardHeader>
            <CardContent className="pb-2">
              {projects.length === 0 ? (
                <div className="text-center py-6 text-muted-foreground">
                  No projects yet
                </div>
              ) : (
                <div className="space-y-2">
                  {projects.slice(0, 5).map(project => (
                    <Link 
                      key={project.id}
                      to={`/projects/${project.id}`}
                      className="flex items-center p-2 rounded-md hover:bg-accent transition-colors"
                    >
                      <FolderKanban className="h-4 w-4 mr-2 text-primary" />
                      <span className="truncate">{project.name}</span>
                    </Link>
                  ))}
                  
                  {projects.length > 5 && (
                    <div className="text-center text-sm text-muted-foreground pt-2">
                      +{projects.length - 5} more projects
                    </div>
                  )}
                </div>
              )}
            </CardContent>
            <CardFooter>
              <Button asChild className="w-full">
                <Link to="/projects/new">
                  <Plus className="h-4 w-4 mr-2" />
                  New Project
                </Link>
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </AppLayout>
  );
};

export default Dashboard;