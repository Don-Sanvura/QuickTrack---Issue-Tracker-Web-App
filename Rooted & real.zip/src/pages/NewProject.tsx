import { useNavigate } from 'react-router-dom';
import AppLayout from '@/components/layout/AppLayout';
import ProjectForm from '@/components/projects/ProjectForm';

const NewProject = () => {
  const navigate = useNavigate();
  
  const handleSuccess = () => {
    navigate('/projects');
  };
  
  const handleCancel = () => {
    navigate('/projects');
  };
  
  return (
    <AppLayout>
      <div className="mb-6">
        <h1 className="text-3xl font-bold mb-2">New Project</h1>
        <p className="text-muted-foreground">
          Create a new project for your team
        </p>
      </div>
      
      <div className="max-w-2xl mx-auto">
        <ProjectForm 
          onSuccess={handleSuccess} 
          onCancel={handleCancel} 
        />
      </div>
    </AppLayout>
  );
};

export default NewProject;