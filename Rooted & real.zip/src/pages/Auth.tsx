import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import LoginForm from '@/components/auth/LoginForm';
import RegisterForm from '@/components/auth/RegisterForm';
import { initDemoData } from '@/lib/localStorage';
import { ModeToggle } from '@/components/theme/ModeToggle';

enum AuthMode {
  LOGIN,
  REGISTER
}

const Auth = () => {
  const [mode, setMode] = useState<AuthMode>(AuthMode.LOGIN);
  const { currentUser } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    // Initialize demo data if needed
    initDemoData();
    
    // Redirect if already logged in
    if (currentUser) {
      navigate('/');
    }
  }, [currentUser, navigate]);

  const handleSuccess = () => {
    navigate('/');
  };

  return (
    <div className="flex min-h-screen items-center justify-center p-4 bg-background">
      <div className="absolute right-4 top-4">
        <ModeToggle />
      </div>
      
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold">
            Quick<span className="text-primary">Track</span>
          </h1>
          <p className="text-muted-foreground mt-2">
            A lightweight issue tracker for small teams
          </p>
        </div>
        
        {mode === AuthMode.LOGIN ? (
          <LoginForm 
            onSuccess={handleSuccess} 
            onRegisterClick={() => setMode(AuthMode.REGISTER)} 
          />
        ) : (
          <RegisterForm 
            onSuccess={handleSuccess} 
            onLoginClick={() => setMode(AuthMode.LOGIN)} 
          />
        )}
      </div>
    </div>
  );
};

export default Auth;