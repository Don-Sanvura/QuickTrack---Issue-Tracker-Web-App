import { Toaster } from '@/components/ui/sonner';
import { TooltipProvider } from '@/components/ui/tooltip';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useEffect } from 'react';

// Contexts
import { ThemeProvider } from '@/contexts/ThemeContext';
import { AuthProvider } from '@/contexts/AuthContext';
import { ProjectProvider } from '@/contexts/ProjectContext';
import { TaskProvider } from '@/contexts/TaskContext';
import { CommentProvider } from '@/contexts/CommentContext';
import { NotificationProvider } from '@/contexts/NotificationContext';

// Pages
import Dashboard from './pages/Dashboard';
import Auth from './pages/Auth';
import ProjectList from './pages/ProjectList';
import ProjectDetail from './pages/ProjectDetail';
import NewProject from './pages/NewProject';
import Analytics from './pages/Analytics';
import Settings from './pages/Settings';
import Search from './pages/Search';
import NotFound from './pages/NotFound';

const queryClient = new QueryClient();

// Helper component to initialize the app data and handle theme
const AppInitializer = ({ children }: { children: React.ReactNode }) => {
  // Apply theme class to html element
  useEffect(() => {
    // Check dark mode preference
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    const savedTheme = localStorage.getItem('quicktrack-theme');
    
    if (savedTheme === 'dark' || (!savedTheme && prefersDark)) {
      document.documentElement.classList.add('dark');
    }
  }, []);
  
  return <>{children}</>;
};

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AppInitializer>
      <ThemeProvider>
        <AuthProvider>
          <ProjectProvider>
            <TaskProvider>
              <CommentProvider>
                <NotificationProvider>
                  <TooltipProvider>
                    <Toaster />
                    <BrowserRouter>
                      <Routes>
                        <Route path="/" element={<Dashboard />} />
                        <Route path="/auth" element={<Auth />} />
                        <Route path="/projects" element={<ProjectList />} />
                        <Route path="/projects/new" element={<NewProject />} />
                        <Route path="/projects/:projectId" element={<ProjectDetail />} />
                        <Route path="/analytics" element={<Analytics />} />
                        <Route path="/settings" element={<Settings />} />
                        <Route path="/search" element={<Search />} />
                        <Route path="/404" element={<NotFound />} />
                        <Route path="*" element={<Navigate to="/404" replace />} />
                      </Routes>
                    </BrowserRouter>
                  </TooltipProvider>
                </NotificationProvider>
              </CommentProvider>
            </TaskProvider>
          </ProjectProvider>
        </AuthProvider>
      </ThemeProvider>
    </AppInitializer>
  </QueryClientProvider>
);

export default App;
