import { useState } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useAuth } from '@/contexts/AuthContext';
import { useProjects } from '@/contexts/ProjectContext';
import {
  PanelLeft,
  Home,
  Settings,
  BarChart3,
  Plus,
  FolderKanban,
  ChevronDown,
  ChevronRight,
} from 'lucide-react';

const Sidebar = () => {
  const [collapsed, setCollapsed] = useState(false);
  const [projectsExpanded, setProjectsExpanded] = useState(true);
  const { isAdmin } = useAuth();
  const { projects } = useProjects();
  const location = useLocation();

  return (
    <aside
      className={cn(
        "bg-card border-r flex flex-col transition-all duration-300",
        collapsed ? "w-16" : "w-64"
      )}
    >
      <div className="p-4 border-b flex items-center justify-between h-[61px]">
        {!collapsed && (
          <h1 className="font-bold text-xl">
            Quick<span className="text-primary">Track</span>
          </h1>
        )}
        <Button 
          variant="ghost" 
          size="icon"
          onClick={() => setCollapsed(!collapsed)} 
          className={cn("ml-auto", collapsed && "mx-auto")}
        >
          <PanelLeft className="h-4 w-4" />
        </Button>
      </div>
      <ScrollArea className="flex-1">
        <div className="p-2">
          <nav className="space-y-1">
            <NavLink
              to="/"
              className={({ isActive }) =>
                cn(
                  "flex items-center gap-3 px-3 py-2 rounded-md text-sm",
                  "transition-colors hover:bg-accent hover:text-accent-foreground",
                  isActive
                    ? "bg-accent text-accent-foreground"
                    : "text-muted-foreground",
                  collapsed && "justify-center px-0"
                )
              }
            >
              <Home className="h-4 w-4" />
              {!collapsed && <span>Dashboard</span>}
            </NavLink>

            {isAdmin && (
              <NavLink
                to="/analytics"
                className={({ isActive }) =>
                  cn(
                    "flex items-center gap-3 px-3 py-2 rounded-md text-sm",
                    "transition-colors hover:bg-accent hover:text-accent-foreground",
                    isActive
                      ? "bg-accent text-accent-foreground"
                      : "text-muted-foreground",
                    collapsed && "justify-center px-0"
                  )
                }
              >
                <BarChart3 className="h-4 w-4" />
                {!collapsed && <span>Analytics</span>}
              </NavLink>
            )}

            <NavLink
              to="/settings"
              className={({ isActive }) =>
                cn(
                  "flex items-center gap-3 px-3 py-2 rounded-md text-sm",
                  "transition-colors hover:bg-accent hover:text-accent-foreground",
                  isActive
                    ? "bg-accent text-accent-foreground"
                    : "text-muted-foreground",
                  collapsed && "justify-center px-0"
                )
              }
            >
              <Settings className="h-4 w-4" />
              {!collapsed && <span>Settings</span>}
            </NavLink>
          </nav>

          {!collapsed && (
            <div className="mt-6">
              <div 
                className="flex items-center justify-between px-3 py-2 text-sm font-medium cursor-pointer"
                onClick={() => setProjectsExpanded(!projectsExpanded)}
              >
                <span>Projects</span>
                <Button variant="ghost" size="icon" className="h-5 w-5">
                  {projectsExpanded ? (
                    <ChevronDown className="h-4 w-4" />
                  ) : (
                    <ChevronRight className="h-4 w-4" />
                  )}
                </Button>
              </div>
              
              {projectsExpanded && (
                <div className="mt-1 space-y-1">
                  {projects.map((project) => (
                    <NavLink
                      key={project.id}
                      to={`/projects/${project.id}`}
                      className={({ isActive }) =>
                        cn(
                          "flex items-center px-3 py-2 text-sm rounded-md ml-3 mr-1",
                          "transition-colors hover:bg-accent hover:text-accent-foreground",
                          isActive
                            ? "bg-accent text-accent-foreground"
                            : "text-muted-foreground"
                        )
                      }
                    >
                      <FolderKanban className="h-4 w-4 mr-2 shrink-0" />
                      <span className="truncate">{project.name}</span>
                    </NavLink>
                  ))}
                  <NavLink
                    to="/projects/new"
                    className={cn(
                      "flex items-center px-3 py-2 text-sm rounded-md ml-3 mr-1",
                      "transition-colors hover:bg-accent hover:text-accent-foreground",
                      "text-muted-foreground"
                    )}
                  >
                    <Plus className="h-4 w-4 mr-2 shrink-0" />
                    <span>New Project</span>
                  </NavLink>
                </div>
              )}
            </div>
          )}

          {collapsed && (
            <div className="mt-6 flex flex-col items-center">
              <Button variant="ghost" size="icon" className="mb-1" asChild>
                <NavLink to="/projects/new">
                  <Plus className="h-4 w-4" />
                </NavLink>
              </Button>
              
              {projects.slice(0, 5).map((project) => (
                <Button
                  key={project.id}
                  variant="ghost"
                  size="icon"
                  className={cn(
                    "mb-1",
                    location.pathname === `/projects/${project.id}` && "bg-accent"
                  )}
                  asChild
                >
                  <NavLink to={`/projects/${project.id}`}>
                    <FolderKanban className="h-4 w-4" />
                  </NavLink>
                </Button>
              ))}
            </div>
          )}
        </div>
      </ScrollArea>
    </aside>
  );
};

export default Sidebar;