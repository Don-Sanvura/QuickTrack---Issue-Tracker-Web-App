import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useTasks } from '@/contexts/TaskContext';
import { TaskPriority } from '@/types';

const PriorityDistribution = () => {
  const { tasks, getTaskStats } = useTasks();
  const stats = getTaskStats();
  
  const priorityConfig = [
    { 
      priority: TaskPriority.LOW, 
      label: 'Low', 
      color: 'bg-slate-500',
      textColor: 'text-slate-500'
    },
    { 
      priority: TaskPriority.MEDIUM, 
      label: 'Medium', 
      color: 'bg-blue-500',
      textColor: 'text-blue-500'
    },
    { 
      priority: TaskPriority.HIGH, 
      label: 'High', 
      color: 'bg-amber-500',
      textColor: 'text-amber-500'
    },
    { 
      priority: TaskPriority.CRITICAL, 
      label: 'Critical', 
      color: 'bg-red-500',
      textColor: 'text-red-500'
    },
  ];
  
  // Calculate percentages
  const totalTasks = stats.total;
  const priorityData = priorityConfig.map(({ priority, label, color, textColor }) => {
    const count = stats.byPriority[priority];
    const percentage = totalTasks > 0 ? Math.round((count / totalTasks) * 100) : 0;
    
    return {
      priority,
      label,
      color,
      textColor,
      count,
      percentage
    };
  });

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-xl">Priority Distribution</CardTitle>
      </CardHeader>
      <CardContent>
        {totalTasks === 0 ? (
          <div className="text-center py-6 text-muted-foreground">
            No tasks to analyze
          </div>
        ) : (
          <div className="space-y-6">
            <div className="h-4 w-full flex rounded-full overflow-hidden">
              {priorityData.map(data => (
                <div 
                  key={data.priority}
                  className={`${data.color} h-full`}
                  style={{ width: `${data.percentage}%` }}
                />
              ))}
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              {priorityData.map(data => (
                <div key={data.priority} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className={`${data.color} h-3 w-3 rounded-full`}></div>
                    <span className="text-sm">{data.label}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={`text-sm font-medium ${data.textColor}`}>
                      {data.count}
                    </span>
                    <span className="text-xs text-muted-foreground">
                      ({data.percentage}%)
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default PriorityDistribution;