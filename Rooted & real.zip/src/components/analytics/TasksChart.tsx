import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useTasks } from '@/contexts/TaskContext';
import { TaskStatus, Task } from '@/types';
import { useRef, useEffect, useState } from 'react';
import { format, subDays, differenceInDays } from 'date-fns';
import { cn } from '@/lib/utils';

const TasksChart = () => {
  const { tasks } = useTasks();
  const chartRef = useRef<HTMLDivElement>(null);
  const [maxTasks, setMaxTasks] = useState(0);
  
  // Get data for the last 7 days
  const days = Array.from({ length: 7 }, (_, i) => {
    const date = subDays(new Date(), 6 - i);
    return {
      date,
      label: format(date, 'MMM d'),
      formattedDate: format(date, 'yyyy-MM-dd')
    };
  });
  
  // Process data
  const chartData = days.map(day => {
    const dayStart = new Date(day.date);
    dayStart.setHours(0, 0, 0, 0);
    
    const dayEnd = new Date(day.date);
    dayEnd.setHours(23, 59, 59, 999);
    
    const tasksCreated = tasks.filter(task => {
      const createdAt = new Date(task.createdAt);
      return createdAt >= dayStart && createdAt <= dayEnd;
    }).length;
    
    const tasksCompleted = tasks.filter(task => {
      const updatedAt = new Date(task.updatedAt);
      return task.status === TaskStatus.DONE && 
        updatedAt >= dayStart && 
        updatedAt <= dayEnd;
    }).length;
    
    return {
      day: day.label,
      formattedDate: day.formattedDate,
      created: tasksCreated,
      completed: tasksCompleted
    };
  });

  useEffect(() => {
    // Calculate max value for chart scale
    const maxCreated = Math.max(...chartData.map(d => d.created));
    const maxCompleted = Math.max(...chartData.map(d => d.completed));
    setMaxTasks(Math.max(maxCreated, maxCompleted, 5)); // minimum of 5 for visual scale
  }, [tasks]);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-xl">Task Activity</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-[300px]" ref={chartRef}>
          <div className="flex items-end justify-between h-[250px] gap-2">
            {chartData.map((data, index) => (
              <div
                key={data.formattedDate}
                className="flex-1 flex flex-col items-center gap-1"
              >
                <div className="w-full flex flex-col items-center justify-end h-[200px]">
                  <div
                    className="w-full max-w-[30px] bg-primary/60 rounded-t"
                    style={{
                      height: `${maxTasks > 0 ? (data.created / maxTasks) * 100 : 0}%`,
                      minHeight: data.created > 0 ? '4px' : 0
                    }}
                  />
                  <div 
                    className={cn(
                      "w-full max-w-[30px] bg-green-500/60 rounded-t mt-1",
                      data.completed === 0 && "hidden"
                    )}
                    style={{
                      height: `${maxTasks > 0 ? (data.completed / maxTasks) * 100 : 0}%`,
                      minHeight: data.completed > 0 ? '4px' : 0
                    }}
                  />
                </div>
                <div 
                  className={cn(
                    "text-xs text-center w-full truncate", 
                    index === days.length - 1 && "font-semibold text-primary"
                  )}
                >
                  {data.day}
                </div>
              </div>
            ))}
          </div>
          
          <div className="flex justify-center space-x-4 mt-4">
            <div className="flex items-center">
              <div className="w-3 h-3 bg-primary/60 rounded mr-2"></div>
              <span className="text-sm">Created</span>
            </div>
            <div className="flex items-center">
              <div className="w-3 h-3 bg-green-500/60 rounded mr-2"></div>
              <span className="text-sm">Completed</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default TasksChart;