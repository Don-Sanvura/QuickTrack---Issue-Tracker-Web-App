import { useState, useEffect } from 'react';
import { Comment as CommentType } from '@/types';
import { useComments } from '@/contexts/CommentContext';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { MessageSquare, Send, Trash2 } from 'lucide-react';
import { getUsers } from '@/lib/localStorage';
import { format } from 'date-fns';

interface CommentSectionProps {
  taskId: string;
}

interface CommentWithUser extends CommentType {
  userName: string;
  userInitials: string;
}

const CommentSection = ({ taskId }: CommentSectionProps) => {
  const { currentUser } = useAuth();
  const { getTaskComments, addComment, deleteComment } = useComments();
  const [content, setContent] = useState('');
  const [comments, setComments] = useState<CommentWithUser[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const loadComments = () => {
    const taskComments = getTaskComments(taskId);
    const users = getUsers();
    
    const commentsWithUserInfo = taskComments.map(comment => {
      const user = users.find(u => u.id === comment.userId);
      return {
        ...comment,
        userName: user?.name || 'Unknown User',
        userInitials: user ? user.name
          .split(' ')
          .map((n) => n[0])
          .join('')
          .toUpperCase()
          .slice(0, 2) : '??'
      };
    });
    
    // Sort by newest first
    commentsWithUserInfo.sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
    
    setComments(commentsWithUserInfo);
  };

  useEffect(() => {
    loadComments();
  }, [taskId]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser || !content.trim()) return;
    
    setIsSubmitting(true);
    try {
      addComment(taskId, content.trim());
      setContent('');
      loadComments(); // Reload comments after adding
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = (commentId: string) => {
    deleteComment(commentId);
    loadComments(); // Reload comments after deletion
  };

  const userInitials = currentUser?.name
    ?.split(' ')
    .map((n) => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);

  return (
    <div className="space-y-4">
      <h3 className="text-sm font-medium flex items-center gap-1">
        <MessageSquare className="h-4 w-4" /> 
        Comments ({comments.length})
      </h3>

      <form onSubmit={handleSubmit} className="flex gap-3">
        <Avatar className="h-8 w-8 flex-shrink-0 mt-1">
          <AvatarFallback>{userInitials}</AvatarFallback>
        </Avatar>
        <div className="flex-1 space-y-2">
          <Textarea
            placeholder="Write a comment..."
            value={content}
            onChange={(e) => setContent(e.target.value)}
            className="min-h-[80px]"
          />
          <Button 
            type="submit" 
            size="sm" 
            disabled={!content.trim() || isSubmitting} 
            className="ml-auto"
          >
            {isSubmitting ? 'Posting...' : 'Post Comment'} <Send className="ml-1 h-4 w-4" />
          </Button>
        </div>
      </form>

      {comments.length > 0 ? (
        <div className="space-y-4 pt-2">
          {comments.map((comment) => (
            <div key={comment.id} className="flex gap-3">
              <Avatar className="h-8 w-8 flex-shrink-0">
                <AvatarFallback>{comment.userInitials}</AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <div className="bg-secondary/30 p-3 rounded-md">
                  <div className="flex justify-between items-start">
                    <div className="font-medium text-sm">{comment.userName}</div>
                    {currentUser?.id === comment.userId && (
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-6 w-6 -mt-1 -mr-1 text-muted-foreground"
                        onClick={() => handleDelete(comment.id)}
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    )}
                  </div>
                  <div className="text-sm mt-1">{comment.content}</div>
                </div>
                <div className="text-xs text-muted-foreground mt-1">
                  {format(new Date(comment.createdAt), 'MMM d, yyyy h:mm a')}
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-6 text-muted-foreground">
          No comments yet. Be the first to comment!
        </div>
      )}
    </div>
  );
};

export default CommentSection;