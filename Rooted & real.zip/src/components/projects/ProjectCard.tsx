import { Project } from '@/types';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { FolderKanban, MoreHorizontal } from 'lucide-react';
import { format } from 'date-fns';
import { Link } from 'react-router-dom';
import { useTasks } from '@/contexts/TaskContext';
import { Badge } from '@/components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useAuth } from '@/contexts/AuthContext';

interface ProjectCardProps {
  project: Project;
  onEdit: () => void;
  onDelete: () => void;
}

const ProjectCard = ({ project, onEdit, onDelete }: ProjectCardProps) => {
  const { getProjectTasks } = useTasks();
  const { isAdmin } = useAuth();
  
  const projectTasks = getProjectTasks(project.id);
  const totalTasks = projectTasks.length;
  const completedTasks = projectTasks.filter(task => task.status === 'done').length;

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
        <CardTitle className="text-xl flex items-center gap-2">
          <FolderKanban className="h-5 w-5 text-primary" />
          <span className="truncate">{project.name}</span>
        </CardTitle>
        {isAdmin && (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon">
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={onEdit}>Edit</DropdownMenuItem>
              <DropdownMenuItem 
                className="text-destructive focus:text-destructive" 
                onClick={onDelete}
              >
                Delete
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        )}
      </CardHeader>
      <CardContent className="pb-2">
        <p className="text-sm text-muted-foreground line-clamp-2 h-10">
          {project.description || "No description provided"}
        </p>
        <div className="flex justify-between mt-4 text-xs text-muted-foreground">
          <span>Created {format(new Date(project.createdAt), 'MMM d, yyyy')}</span>
          <div className="flex items-center">
            <Badge variant="secondary" className="text-xs">
              {completedTasks}/{totalTasks} tasks
            </Badge>
          </div>
        </div>
      </CardContent>
      <CardFooter>
        <Button asChild className="w-full">
          <Link to={`/projects/${project.id}`}>
            View Project
          </Link>
        </Button>
      </CardFooter>
    </Card>
  );
};

export default ProjectCard;