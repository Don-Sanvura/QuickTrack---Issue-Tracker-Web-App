import { useTasks } from '@/contexts/TaskContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TaskStatus, TaskPriority } from '@/types';
import { useNavigate } from 'react-router-dom';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';

const RecentTasks = () => {
  const { tasks } = useTasks();
  const navigate = useNavigate();
  
  // Status configuration
  const statusConfig: Record<TaskStatus, { label: string; color: string }> = {
    [TaskStatus.TODO]: { label: 'To Do', color: 'bg-slate-500 text-slate-50' },
    [TaskStatus.IN_PROGRESS]: { label: 'In Progress', color: 'bg-blue-500 text-blue-50' },
    [TaskStatus.REVIEW]: { label: 'Review', color: 'bg-amber-500 text-amber-50' },
    [TaskStatus.DONE]: { label: 'Done', color: 'bg-green-500 text-green-50' },
  };
  
  // Priority configuration
  const priorityConfig: Record<TaskPriority, { label: string; color: string }> = {
    [TaskPriority.LOW]: { label: 'Low', color: 'bg-slate-500 text-slate-50' },
    [TaskPriority.MEDIUM]: { label: 'Medium', color: 'bg-blue-500 text-blue-50' },
    [TaskPriority.HIGH]: { label: 'High', color: 'bg-amber-500 text-amber-50' },
    [TaskPriority.CRITICAL]: { label: 'Critical', color: 'bg-red-500 text-red-50' },
  };
  
  // Sort by most recently updated
  const recentTasks = [...tasks]
    .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime())
    .slice(0, 5);
  
  const handleTaskClick = (projectId: string, taskId: string) => {
    navigate(`/projects/${projectId}?task=${taskId}`);
  };
  
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-xl">Recent Tasks</CardTitle>
      </CardHeader>
      <CardContent>
        {recentTasks.length === 0 ? (
          <div className="text-center py-6 text-muted-foreground">
            No tasks yet
          </div>
        ) : (
          <div className="space-y-2">
            {recentTasks.map(task => (
              <div 
                key={task.id} 
                className="flex items-start justify-between p-3 bg-secondary/30 rounded-md cursor-pointer hover:bg-secondary/50 transition-colors"
                onClick={() => handleTaskClick(task.projectId, task.id)}
              >
                <div className="space-y-1 flex-1 min-w-0">
                  <div className="font-medium truncate">{task.title}</div>
                  <div className="flex gap-2">
                    <Badge className={statusConfig[task.status as TaskStatus].color}>
                      {statusConfig[task.status as TaskStatus].label}
                    </Badge>
                    <Badge className={priorityConfig[task.priority as TaskPriority].color}>
                      {priorityConfig[task.priority as TaskPriority].label}
                    </Badge>
                  </div>
                </div>
                <div className="text-xs text-muted-foreground ml-4 flex-shrink-0">
                  {format(new Date(task.updatedAt), 'MMM d, h:mm a')}
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default RecentTasks;