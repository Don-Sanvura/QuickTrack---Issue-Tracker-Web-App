import { useTasks } from '@/contexts/TaskContext';
import { TaskStatus } from '@/types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';

const TasksOverview = () => {
  const { tasks, getTaskStats } = useTasks();
  const stats = getTaskStats();
  
  // Calculate completion percentage
  const completionPercentage = stats.total > 0 
    ? Math.round((stats.byStatus[TaskStatus.DONE] / stats.total) * 100) 
    : 0;
  
  // Status labels and colors
  const statusConfig = [
    { status: TaskStatus.TODO, label: 'To Do', color: 'bg-slate-500' },
    { status: TaskStatus.IN_PROGRESS, label: 'In Progress', color: 'bg-blue-500' },
    { status: TaskStatus.REVIEW, label: 'Review', color: 'bg-amber-500' },
    { status: TaskStatus.DONE, label: 'Done', color: 'bg-green-500' },
  ];
  
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-xl">Tasks Overview</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Task Completion</span>
              <span className="font-medium">{completionPercentage}%</span>
            </div>
            <Progress value={completionPercentage} className="h-2" />
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {statusConfig.map(({ status, label, color }) => (
              <div 
                key={status} 
                className="bg-card border rounded-md flex flex-col items-center justify-center p-3 gap-1"
              >
                <div className={`${color} h-2 w-2 rounded-full`}></div>
                <span className="font-medium text-xl">{stats.byStatus[status]}</span>
                <span className="text-xs text-muted-foreground">{label}</span>
              </div>
            ))}
          </div>
          
          <div className="text-xs text-muted-foreground text-center pt-2">
            {stats.total} total tasks
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default TasksOverview;