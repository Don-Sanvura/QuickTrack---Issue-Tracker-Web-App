import { useNotifications } from '@/contexts/NotificationContext';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import NotificationItem from './NotificationItem';
import { useEffect } from 'react';

const NotificationList = () => {
  const { 
    getUserNotifications, 
    markAllAsRead, 
    unreadCount 
  } = useNotifications();

  const notifications = getUserNotifications();

  useEffect(() => {
    // Mark all notifications as read when component unmounts
    return () => {
      if (unreadCount > 0) {
        markAllAsRead();
      }
    };
  }, [unreadCount, markAllAsRead]);

  return (
    <div className="flex flex-col h-full pt-4">
      <div className="flex justify-between items-center mb-4">
        <span className="text-sm text-muted-foreground">
          {unreadCount} unread {unreadCount === 1 ? 'notification' : 'notifications'}
        </span>
        {unreadCount > 0 && (
          <Button variant="ghost" size="sm" onClick={markAllAsRead}>
            Mark all as read
          </Button>
        )}
      </div>

      <ScrollArea className="flex-1 pr-4">
        {notifications.length === 0 ? (
          <div className="py-8 text-center text-muted-foreground">
            No notifications yet
          </div>
        ) : (
          <div className="space-y-3">
            {notifications
              .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
              .map(notification => (
                <NotificationItem key={notification.id} notification={notification} />
              ))}
          </div>
        )}
      </ScrollArea>
    </div>
  );
};

export default NotificationList;