import { Task, TaskPriority, TaskStatus } from '@/types';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  MoreHorizontal, 
  CalendarClock, 
  ArrowRight, 
  MessageSquare 
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { format } from 'date-fns';
import { useComments } from '@/contexts/CommentContext';
import { getUsers } from '@/lib/localStorage';
import { useState, useEffect } from 'react';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { cn } from '@/lib/utils';

interface TaskCardProps {
  task: Task;
  onView: () => void;
  onEdit: () => void;
  onDelete: () => void;
  onStatusChange: (status: TaskStatus) => void;
}

const TaskCard = ({ 
  task, 
  onView, 
  onEdit, 
  onDelete,
  onStatusChange 
}: TaskCardProps) => {
  const { getTaskComments } = useComments();
  const [assignee, setAssignee] = useState<string>('Unassigned');
  const [assigneeInitials, setAssigneeInitials] = useState<string>('');
  const comments = getTaskComments(task.id);
  
  // Status configuration
  const statusConfig: Record<TaskStatus, { label: string; color: string }> = {
    [TaskStatus.TODO]: { 
      label: 'To Do', 
      color: 'bg-slate-500 hover:bg-slate-600' 
    },
    [TaskStatus.IN_PROGRESS]: { 
      label: 'In Progress', 
      color: 'bg-blue-500 hover:bg-blue-600' 
    },
    [TaskStatus.REVIEW]: { 
      label: 'Review', 
      color: 'bg-amber-500 hover:bg-amber-600' 
    },
    [TaskStatus.DONE]: { 
      label: 'Done', 
      color: 'bg-green-500 hover:bg-green-600' 
    },
  };
  
  // Priority configuration
  const priorityConfig: Record<TaskPriority, { label: string; color: string }> = {
    [TaskPriority.LOW]: { 
      label: 'Low', 
      color: 'bg-slate-500 text-slate-50' 
    },
    [TaskPriority.MEDIUM]: { 
      label: 'Medium', 
      color: 'bg-blue-500 text-blue-50' 
    },
    [TaskPriority.HIGH]: { 
      label: 'High', 
      color: 'bg-amber-500 text-amber-50' 
    },
    [TaskPriority.CRITICAL]: { 
      label: 'Critical', 
      color: 'bg-red-500 text-red-50' 
    },
  };
  
  // Get next status
  const getNextStatus = (currentStatus: TaskStatus): TaskStatus | null => {
    switch (currentStatus) {
      case TaskStatus.TODO:
        return TaskStatus.IN_PROGRESS;
      case TaskStatus.IN_PROGRESS:
        return TaskStatus.REVIEW;
      case TaskStatus.REVIEW:
        return TaskStatus.DONE;
      default:
        return null;
    }
  };

  useEffect(() => {
    if (task.assignedTo) {
      const users = getUsers();
      const user = users.find(u => u.id === task.assignedTo);
      if (user) {
        setAssignee(user.name);
        setAssigneeInitials(user.name
          .split(' ')
          .map((n) => n[0])
          .join('')
          .toUpperCase()
          .slice(0, 2)
        );
      }
    }
  }, [task.assignedTo]);
  
  const nextStatus = getNextStatus(task.status as TaskStatus);

  return (
    <Card className={cn(
      "overflow-hidden transition-all",
      task.status === TaskStatus.DONE && "opacity-75"
    )}>
      <CardContent className="p-4">
        <div className="flex justify-between items-start">
          <h3 
            className="font-medium cursor-pointer hover:text-primary truncate"
            onClick={onView}
          >
            {task.title}
          </h3>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="h-8 w-8">
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={onView}>View Details</DropdownMenuItem>
              <DropdownMenuItem onClick={onEdit}>Edit</DropdownMenuItem>
              <DropdownMenuItem 
                className="text-destructive focus:text-destructive" 
                onClick={onDelete}
              >
                Delete
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
        
        <div className="flex gap-2 mt-2">
          <Badge variant="secondary">
            {statusConfig[task.status as TaskStatus].label}
          </Badge>
          <Badge className={priorityConfig[task.priority as TaskPriority].color}>
            {priorityConfig[task.priority as TaskPriority].label}
          </Badge>
        </div>
        
        <p className="text-sm text-muted-foreground mt-3 line-clamp-2 h-10">
          {task.description || "No description provided"}
        </p>
        
        <div className="flex justify-between items-center mt-3">
          {task.assignedTo ? (
            <div className="flex items-center gap-2">
              <Avatar className="h-6 w-6">
                <AvatarFallback className="text-xs">
                  {assigneeInitials}
                </AvatarFallback>
              </Avatar>
              <span className="text-xs text-muted-foreground truncate">
                {assignee}
              </span>
            </div>
          ) : (
            <span className="text-xs text-muted-foreground">Unassigned</span>
          )}
          
          {task.dueDate && (
            <div className="flex items-center text-xs text-muted-foreground">
              <CalendarClock className="h-3 w-3 mr-1" />
              <span>{format(new Date(task.dueDate), 'MMM d')}</span>
            </div>
          )}
        </div>
        
        {comments.length > 0 && (
          <div className="mt-3 text-xs text-muted-foreground flex items-center">
            <MessageSquare className="h-3 w-3 mr-1" />
            <span>{comments.length} {comments.length === 1 ? 'comment' : 'comments'}</span>
          </div>
        )}
      </CardContent>
      
      {nextStatus && (
        <CardFooter className="p-0">
          <Button
            variant="ghost" 
            className={cn(
              "w-full rounded-none h-8 text-white text-xs",
              statusConfig[nextStatus].color
            )}
            onClick={() => onStatusChange(nextStatus)}
          >
            Move to {statusConfig[nextStatus].label} <ArrowRight className="ml-1 h-3 w-3" />
          </Button>
        </CardFooter>
      )}
    </Card>
  );
};

export default TaskCard;