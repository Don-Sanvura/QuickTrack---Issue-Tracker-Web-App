import { useState, useEffect } from 'react';
import { Task, TaskPriority, TaskStatus, User } from '@/types';
import { getUsers } from '@/lib/localStorage';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { 
  CalendarClock, 
  Clock,
  Edit2, 
  Trash2,
  CheckCircle, 
  AlignLeft,
  User as UserIcon
} from 'lucide-react';
import { format } from 'date-fns';
import { useAuth } from '@/contexts/AuthContext';
import { cn } from '@/lib/utils';
import CommentSection from '../comments/CommentSection';

interface TaskDetailProps {
  task: Task;
  onEdit: () => void;
  onDelete: () => void;
  onStatusChange: (status: TaskStatus) => void;
}

const TaskDetail = ({ task, onEdit, onDelete, onStatusChange }: TaskDetailProps) => {
  const { currentUser, isAdmin } = useAuth();
  const [assignee, setAssignee] = useState<User | null>(null);
  const [creator, setCreator] = useState<User | null>(null);
  
  // Status configuration
  const statusOptions: { value: TaskStatus; label: string; color: string }[] = [
    { value: TaskStatus.TODO, label: 'To Do', color: 'bg-slate-100 text-slate-700 hover:bg-slate-200' },
    { value: TaskStatus.IN_PROGRESS, label: 'In Progress', color: 'bg-blue-100 text-blue-700 hover:bg-blue-200' },
    { value: TaskStatus.REVIEW, label: 'Review', color: 'bg-amber-100 text-amber-700 hover:bg-amber-200' },
    { value: TaskStatus.DONE, label: 'Done', color: 'bg-green-100 text-green-700 hover:bg-green-200' },
  ];
  
  // Priority configuration
  const priorityConfig: Record<TaskPriority, { label: string; color: string }> = {
    [TaskPriority.LOW]: { label: 'Low', color: 'bg-slate-500 text-slate-50' },
    [TaskPriority.MEDIUM]: { label: 'Medium', color: 'bg-blue-500 text-blue-50' },
    [TaskPriority.HIGH]: { label: 'High', color: 'bg-amber-500 text-amber-50' },
    [TaskPriority.CRITICAL]: { label: 'Critical', color: 'bg-red-500 text-red-50' },
  };

  useEffect(() => {
    const users = getUsers();
    
    // Get assignee
    if (task.assignedTo) {
      const foundAssignee = users.find(u => u.id === task.assignedTo);
      if (foundAssignee) setAssignee(foundAssignee);
    }
    
    // Get creator
    const foundCreator = users.find(u => u.id === task.createdBy);
    if (foundCreator) setCreator(foundCreator);
  }, [task]);

  // Check if current user can edit/delete the task
  const canModify = isAdmin || (currentUser?.id === task.createdBy) || (currentUser?.id === task.assignedTo);

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex justify-between items-start">
          <CardTitle className="text-xl pr-4">{task.title}</CardTitle>
          {canModify && (
            <div className="flex gap-2">
              <Button 
                variant="outline" 
                size="icon" 
                onClick={onEdit}
                aria-label="Edit task"
              >
                <Edit2 className="h-4 w-4" />
              </Button>
              <Button 
                variant="outline" 
                size="icon" 
                className="text-destructive hover:text-destructive"
                onClick={onDelete}
                aria-label="Delete task"
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          )}
        </div>
        
        <div className="flex flex-wrap gap-2 mt-2">
          <Badge className={priorityConfig[task.priority as TaskPriority].color}>
            {priorityConfig[task.priority as TaskPriority].label}
          </Badge>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <div className="flex flex-col md:flex-row justify-between gap-4">
          <div className="flex-1 space-y-4">
            <div>
              <h3 className="text-sm font-medium flex items-center gap-1 mb-1">
                <AlignLeft className="h-4 w-4" /> Description
              </h3>
              <div className="bg-secondary/30 p-3 rounded-md text-sm">
                {task.description || "No description provided"}
              </div>
            </div>
          </div>
          
          <div className="w-full md:w-48 lg:w-64 space-y-4">
            <div>
              <h3 className="text-sm font-medium mb-1">Status</h3>
              <div className="flex flex-wrap gap-2">
                {statusOptions.map(status => (
                  <Button
                    key={status.value}
                    variant="outline"
                    size="sm"
                    className={cn(
                      status.color,
                      "border-none",
                      task.status === status.value ? "ring-2 ring-primary" : ""
                    )}
                    disabled={task.status === status.value}
                    onClick={() => onStatusChange(status.value)}
                  >
                    {status.label}
                    {task.status === status.value && (
                      <CheckCircle className="ml-1 h-3 w-3" />
                    )}
                  </Button>
                ))}
              </div>
            </div>
            
            <div>
              <h3 className="text-sm font-medium mb-1 flex items-center gap-1">
                <UserIcon className="h-4 w-4" /> Assignee
              </h3>
              <div className="text-sm">
                {assignee ? assignee.name : "Unassigned"}
              </div>
            </div>
            
            {task.dueDate && (
              <div>
                <h3 className="text-sm font-medium mb-1 flex items-center gap-1">
                  <CalendarClock className="h-4 w-4" /> Due Date
                </h3>
                <div className="text-sm">
                  {format(new Date(task.dueDate), 'PPP')}
                </div>
              </div>
            )}
            
            <div>
              <h3 className="text-sm font-medium mb-1 flex items-center gap-1">
                <Clock className="h-4 w-4" /> Created
              </h3>
              <div className="text-sm">
                {format(new Date(task.createdAt), 'PPP')}
                {creator && (
                  <div className="text-muted-foreground text-xs">
                    by {creator.name}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
        
        <Separator />
        
        <CommentSection taskId={task.id} />
      </CardContent>
    </Card>
  );
};

export default TaskDetail;